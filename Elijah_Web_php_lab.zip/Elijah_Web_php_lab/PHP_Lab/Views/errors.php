<?php include("Views/header.php"); ?>

<div class="mainBody">	
	<h1>Something went wrong please go back and try again.</h1>
</div>
</main>

<?php include("Views/footer.php"); ?>
