Notes:
- To get the database to import I had to already have a database with its name made and import it into there.

User Accounts:

UserName   Password
Admin1		Password
Master      Password1234


Changes from peer reviews:

As each peer review said the design was lackluster. I took some extra time to try and improve upon it taking and acting upon suggestions from people. 
Another thing chnaged based off of the reviews was I made some of the instructions on the site a little clearer.